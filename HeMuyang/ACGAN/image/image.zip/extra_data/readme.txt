


The images are in ‘images’ along with the images' tags in the 
csv file 'tags.csv'

Note that all images have been flipped horizontally.


